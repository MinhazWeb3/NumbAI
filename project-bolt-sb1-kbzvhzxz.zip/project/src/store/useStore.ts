import { create } from 'zustand';
import { User, Project, Task } from '../types';

interface Store {
  user: User | null;
  projects: Project[];
  tasks: Task[];
  setUser: (user: User | null) => void;
  addNumbPoints: (points: number) => void;
  useStars: (amount: number) => boolean;
  updateLastMiningTime: (timestamp: number) => void;
  activateAIBoost: (multiplier: number, duration: number) => void;
  completeTask: (taskId: string) => void;
}

export const useStore = create<Store>((set) => ({
  user: {
    id: '1', // Demo user
    numbPoints: 0,
    stars: 100,
    referralCode: 'DEMO123',
    lastMiningTime: 0,
    completedTasks: [],
    activeBoosts: {}
  },
  projects: [],
  tasks: [],
  
  setUser: (user) => set({ user }),
  
  addNumbPoints: (points) => 
    set((state) => ({
      user: state.user 
        ? { ...state.user, numbPoints: (state.user.numbPoints || 0) + points }
        : null
    })),
    
  useStars: (amount) => {
    let success = false;
    set((state) => {
      if (state.user && state.user.stars >= amount) {
        success = true;
        return {
          user: { ...state.user, stars: state.user.stars - amount }
        };
      }
      return state;
    });
    return success;
  },

  updateLastMiningTime: (timestamp) =>
    set((state) => ({
      user: state.user
        ? { ...state.user, lastMiningTime: timestamp }
        : null
    })),

  activateAIBoost: (multiplier, duration) =>
    set((state) => ({
      user: state.user
        ? {
            ...state.user,
            activeBoosts: {
              ...state.user.activeBoosts,
              aiBoost: {
                multiplier,
                expiresAt: duration === Number.POSITIVE_INFINITY 
                  ? Number.POSITIVE_INFINITY 
                  : Date.now() + duration
              }
            }
          }
        : null
    })),

  completeTask: (taskId) =>
    set((state) => ({
      user: state.user
        ? {
            ...state.user,
            completedTasks: [...(state.user.completedTasks || []), taskId]
          }
        : null
    })),
}));