export const MINING_COOLDOWN = 8 * 60 * 60 * 1000; // 8 hours in milliseconds
export const BASE_MINING_RATE = 0.059; // NUMB per hour
export const AI_BOOST_MULTIPLIER = 3;

export const calculateMiningReward = (user: any): number => {
  const baseReward = BASE_MINING_RATE * 8; // 8 hours worth of mining
  const aiBoostMultiplier = user?.activeBoosts?.aiBoost?.multiplier || 1;
  
  return baseReward * aiBoostMultiplier;
};

export const calculateHourlyRate = (user: any): number => {
  const aiBoostMultiplier = user?.activeBoosts?.aiBoost?.multiplier || 1;
  return BASE_MINING_RATE * aiBoostMultiplier;
};

export const canMine = (lastMiningTime?: number): boolean => {
  if (!lastMiningTime) return true;
  const now = Date.now();
  return now - lastMiningTime >= MINING_COOLDOWN;
};

export const formatTimeLeft = (lastMiningTime?: number): string => {
  if (!lastMiningTime) return '8:00:00';
  
  const now = Date.now();
  const timeLeft = Math.max(0, MINING_COOLDOWN - (now - lastMiningTime));
  
  if (timeLeft === 0) return '0:00:00';
  
  const hours = Math.floor(timeLeft / (60 * 60 * 1000));
  const minutes = Math.floor((timeLeft % (60 * 60 * 1000)) / (60 * 1000));
  const seconds = Math.floor((timeLeft % (60 * 1000)) / 1000);
  
  return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
};