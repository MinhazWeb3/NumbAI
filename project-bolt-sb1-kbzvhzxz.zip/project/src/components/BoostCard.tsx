import React from 'react';
import { useStore } from '../store/useStore';
import { Zap } from 'lucide-react';

interface BoostCardProps {
  title: string;
  multiplier: number;
  cost: number;
  type: 'basic' | 'premium';
}

export const BoostCard = ({ title, multiplier, cost, type }: BoostCardProps) => {
  const { useStars } = useStore();

  const handleBoost = () => {
    if (useStars(cost)) {
      // Apply boost logic here
    }
  };

  return (
    <div className="bg-gray-900 rounded-lg p-4 border border-gray-800">
      <div className="flex justify-between items-start mb-3">
        <div>
          <h3 className="font-semibold text-white">{title}</h3>
          <p className="text-sm text-gray-400">{multiplier}x Mining Speed</p>
        </div>
        <Zap className={`${type === 'premium' ? 'text-purple-400' : 'text-blue-400'}`} />
      </div>
      <button
        onClick={handleBoost}
        className={`w-full py-2 rounded-lg text-sm font-medium transition-colors ${
          type === 'premium'
            ? 'bg-purple-500 hover:bg-purple-600'
            : 'bg-blue-500 hover:bg-blue-600'
        }`}
      >
        {cost} Stars
      </button>
    </div>
  );
}