import React, { useState } from 'react';
import { useStore } from '../../store/useStore';
import { Rocket } from 'lucide-react';
import { canMine, calculateMiningReward } from '../../utils/mining';

export const FarmingButton = () => {
  const { user, addNumbPoints, updateLastMiningTime } = useStore();
  const [isAnimating, setIsAnimating] = useState(false);

  const handleMining = () => {
    if (!canMine(user?.lastMiningTime)) return;
    
    setIsAnimating(true);
    setTimeout(() => {
      const reward = calculateMiningReward(user);
      addNumbPoints(reward);
      updateLastMiningTime(Date.now());
      setIsAnimating(false);
    }, 1000);
  };

  const isMiningAvailable = canMine(user?.lastMiningTime);
  const reward = calculateMiningReward(user);

  return (
    <button
      onClick={handleMining}
      disabled={!isMiningAvailable || isAnimating}
      className={`w-full bg-gradient-to-r from-blue-500 to-purple-500 rounded-2xl p-4 text-white font-medium 
        hover:from-blue-600 hover:to-purple-600 transition-all 
        disabled:opacity-50 disabled:cursor-not-allowed
        ${isAnimating ? 'animate-pulse' : ''}`}
    >
      <div className="flex flex-col items-center justify-center gap-1">
        <div className="flex items-center gap-2">
          <Rocket className={isAnimating ? 'animate-bounce' : ''} />
          <span>{isAnimating ? 'Mining...' : isMiningAvailable ? 'Claim NUMB' : 'Cooling Down'}</span>
        </div>
        {isMiningAvailable && (
          <span className="text-sm text-white/60">
            Claim {reward.toFixed(3)} NUMB
          </span>
        )}
      </div>
    </button>
  );
};