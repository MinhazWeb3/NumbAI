import React from 'react';
import { useStore } from '../../store/useStore';
import { formatTimeLeft, calculateHourlyRate } from '../../utils/mining';
import { Card } from '../ui/card';

export const FarmingStatus = () => {
  const { user } = useStore();
  const hourlyRate = calculateHourlyRate(user);
  const estimatedReward = (hourlyRate * 8).toFixed(3);

  return (
    <Card gradient className="bg-gradient-to-r from-blue-400/20 to-purple-400/20">
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <div className="flex items-center gap-3">
            <span className="text-white/80">Farming...</span>
            <span className="text-white/60">{hourlyRate.toFixed(3)} NUMB/hour</span>
          </div>
          <div className="text-sm text-white/40">
            Claimable: {estimatedReward} NUMB
          </div>
        </div>
        <div className="text-right">
          <div className="text-white/60">{formatTimeLeft(user?.lastMiningTime)}</div>
          <div className="text-sm text-white/40">until next claim</div>
        </div>
      </div>
    </Card>
  );
};