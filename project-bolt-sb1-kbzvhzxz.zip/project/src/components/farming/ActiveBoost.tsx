import React from 'react';
import { useStore } from '../../store/useStore';
import { Sparkles } from 'lucide-react';
import { AI_BOOST_MULTIPLIER } from '../../utils/mining';

export const ActiveBoost = () => {
  const { user } = useStore();

  if (!user?.activeBoosts?.aiBoost) return null;

  return (
    <div className="bg-gradient-to-r from-green-500/20 to-blue-500/20 rounded-2xl p-4 flex items-center justify-center min-w-[120px]">
      <div className="text-center">
        <div className="text-green-400 font-medium flex items-center gap-2">
          <Sparkles size={16} />
          <span>AI Boost</span>
        </div>
        <div className="text-sm text-green-400/80">x{AI_BOOST_MULTIPLIER} speed</div>
      </div>
    </div>
  );
};