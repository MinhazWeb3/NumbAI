import React from 'react';
import { useStore } from '../store/useStore';
import { Sparkles, Zap } from 'lucide-react';

export const AIBoost = () => {
  const { user, activateAIBoost } = useStore();

  const handlePurchaseBoost = async () => {
    try {
      // Implement Telegram payment API integration here
      console.log('Initiating Telegram payment...');
      // For demo purposes, activate the boost immediately
      activateAIBoost(3, Number.POSITIVE_INFINITY); // Lifetime boost
    } catch (error) {
      console.error('Payment failed:', error);
    }
  };

  if (user?.activeBoosts?.aiBoost) {
    return (
      <div className="bg-gradient-to-r from-green-500/20 to-blue-500/20 rounded-2xl p-6">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-white font-medium flex items-center gap-2">
              <Sparkles className="text-green-400" size={18} />
              AI Boost Active
            </h3>
            <p className="text-sm text-green-400/80 mt-1">Permanent 3x Mining Power</p>
          </div>
          <div className="bg-green-500/20 px-3 py-1 rounded-full">
            <span className="text-green-400">Active</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-r from-blue-900/50 to-purple-900/50 rounded-2xl p-6">
      <div className="flex items-center gap-3 mb-4">
        <Sparkles className="text-blue-400" />
        <h2 className="text-xl font-bold text-white">AI Boost</h2>
      </div>

      <div className="bg-gray-900/50 rounded-xl p-4 border border-blue-500/20">
        <div className="flex justify-between items-start mb-3">
          <div>
            <h3 className="font-semibold text-white flex items-center gap-2">
              <Zap className="text-blue-400" size={18} />
              Lifetime Enhancement
            </h3>
            <p className="text-sm text-gray-400 mt-1">3x Mining Power Forever</p>
          </div>
          <button
            onClick={handlePurchaseBoost}
            className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
          >
            GET NOW
          </button>
        </div>
        
        <div className="text-xs text-gray-500 mt-4">
          • Permanent AI-powered mining boost
          <br />
          • Triple your NUMB earnings forever
          <br />
          • One-time purchase
        </div>
      </div>
    </div>
  );
}