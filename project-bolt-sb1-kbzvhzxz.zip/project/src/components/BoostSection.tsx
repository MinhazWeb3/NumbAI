import React from 'react';
import { BoostCard } from './BoostCard';

export const BoostSection = () => {
  return (
    <div className="bg-gray-900 rounded-xl p-6">
      <h2 className="text-xl font-bold text-white mb-4">Mining Boosts</h2>
      <div className="space-y-4">
        <BoostCard
          title="Basic Boost"
          multiplier={2}
          cost={10}
          type="basic"
        />
        <BoostCard
          title="Premium Boost"
          multiplier={5}
          cost={25}
          type="premium"
        />
      </div>
    </div>
  );
}