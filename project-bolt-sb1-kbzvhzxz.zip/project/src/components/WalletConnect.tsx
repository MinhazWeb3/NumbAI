import React from 'react';
import { Wallet } from 'lucide-react';
import { TonConnectButton } from '@tonconnect/ui-react';

export const WalletConnect = () => {
  return (
    <TonConnectButton className="flex items-center gap-2 bg-gradient-to-r from-blue-500 to-purple-500 text-white px-4 py-2 rounded-lg hover:from-blue-600 hover:to-purple-600 transition-all">
      <Wallet size={20} />
      <span>Connect</span>
    </TonConnectButton>
  );
};