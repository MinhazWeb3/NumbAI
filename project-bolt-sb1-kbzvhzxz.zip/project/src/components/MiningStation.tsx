import React from 'react';
import { FarmingStatus } from './farming/FarmingStatus';
import { FarmingButton } from './farming/FarmingButton';
import { ActiveBoost } from './farming/ActiveBoost';

export const MiningStation = () => {
  return (
    <div className="space-y-4">
      <FarmingStatus />
      <div className="flex gap-4">
        <div className="flex-1">
          <FarmingButton />
        </div>
        <ActiveBoost />
      </div>
    </div>
  );
};