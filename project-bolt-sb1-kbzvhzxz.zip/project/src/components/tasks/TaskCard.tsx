import React from 'react';
import { Rocket, Users, Share2, MessageCircle, ThumbsUp } from 'lucide-react';
import { Task } from '../../types';
import { Card } from '../ui/card';
import { useStore } from '../../store/useStore';
import { cn } from '../../lib/utils';

const icons = {
  Rocket,
  Users,
  Share2,
  MessageCircle,
  ThumbsUp,
};

interface TaskCardProps {
  task: Task;
  onComplete: (taskId: string) => void;
}

export const TaskCard = ({ task, onComplete }: TaskCardProps) => {
  const { user } = useStore();
  const Icon = icons[task.icon];
  const isCompleted = user?.completedTasks?.includes(task.id);

  return (
    <Card className={cn(
      'transition-all duration-200',
      isCompleted ? 'opacity-50' : 'hover:bg-gray-800/50'
    )}>
      <div className="flex items-start gap-4">
        <div className={cn(
          'p-3 rounded-xl',
          task.reward.type === 'NUMB' ? 'bg-blue-500/20' : 'bg-purple-500/20'
        )}>
          <Icon className={cn(
            'w-6 h-6',
            task.reward.type === 'NUMB' ? 'text-blue-400' : 'text-purple-400'
          )} />
        </div>

        <div className="flex-1">
          <h3 className="font-medium text-white mb-1">{task.title}</h3>
          <p className="text-sm text-gray-400 mb-3">{task.description}</p>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className={cn(
                'text-sm font-medium',
                task.reward.type === 'NUMB' ? 'text-blue-400' : 'text-purple-400'
              )}>
                +{task.reward.amount} {task.reward.type}
              </span>
            </div>
            
            <button
              onClick={() => onComplete(task.id)}
              disabled={isCompleted}
              className={cn(
                'px-4 py-1.5 rounded-lg text-sm font-medium transition-colors',
                isCompleted
                  ? 'bg-gray-700 text-gray-400 cursor-not-allowed'
                  : task.reward.type === 'NUMB'
                    ? 'bg-blue-500 hover:bg-blue-600 text-white'
                    : 'bg-purple-500 hover:bg-purple-600 text-white'
              )}
            >
              {isCompleted ? 'Completed' : 'Complete'}
            </button>
          </div>
        </div>
      </div>
    </Card>
  );
};