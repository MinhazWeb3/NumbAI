import React from 'react';
import { WalletConnect } from './WalletConnect';
import { useStore } from '../store/useStore';
import { Card } from './ui/card';

export const Header = () => {
  const { user } = useStore();
  
  return (
    <div className="bg-black/40 backdrop-blur-sm text-white p-6 text-center">
      <h1 className="text-3xl font-bold tracking-wider mb-4 bg-gradient-to-r from-blue-400 to-purple-400 text-transparent bg-clip-text">
        NUMB
      </h1>
      <p className="text-xl mb-8 text-white/80">Launch your mining shuttle to earn NUMB</p>
      
      <Card className="mx-auto max-w-sm flex justify-between items-center">
        <div>
          <span className="text-4xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 text-transparent bg-clip-text">
            {user?.numbPoints.toFixed(3) || '0.000'}
          </span>
          <p className="text-gray-400 uppercase tracking-wide text-sm">points</p>
        </div>
        <WalletConnect />
      </Card>
    </div>
  );
};