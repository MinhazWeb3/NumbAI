import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Home, Trophy, Gem, Users, Coins } from 'lucide-react';
import { cn } from '../lib/utils';

export const Navigation = () => {
  const navigate = useNavigate();
  const location = useLocation();
  
  const navItems = [
    { path: '/', icon: Home, label: 'Home' },
    { path: '/leaders', icon: Trophy, label: 'Leaders' },
    { path: '/gems', icon: Gem, label: 'Gems' },
    { path: '/friends', icon: Users, label: 'Friends' },
    { path: '/earn', icon: Coins, label: 'Earn' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-black/60 backdrop-blur-lg border-t border-white/10">
      <div className="max-w-lg mx-auto">
        <div className="flex justify-between items-center h-16 px-4">
          {navItems.map(({ path, icon: Icon, label }) => {
            const isActive = location.pathname === path;
            return (
              <button
                key={path}
                onClick={() => navigate(path)}
                className="flex flex-col items-center gap-1 w-16 py-1"
              >
                <Icon
                  size={22}
                  className={cn(
                    'transition-colors duration-200',
                    isActive
                      ? 'text-blue-400'
                      : 'text-gray-500 group-hover:text-gray-300'
                  )}
                />
                <span
                  className={cn(
                    'text-xs transition-colors duration-200',
                    isActive
                      ? 'text-blue-400 font-medium'
                      : 'text-gray-500 group-hover:text-gray-300'
                  )}
                >
                  {label}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
};