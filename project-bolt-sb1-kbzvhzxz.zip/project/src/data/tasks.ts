import { Task } from '../types';

export const dailyTasks: Task[] = [
  {
    id: 'daily-mining',
    title: 'Daily Mining',
    description: 'Complete your first mining operation of the day',
    reward: {
      type: 'NUMB',
      amount: 0.5
    },
    icon: 'Rocket',
    completed: false
  },
  {
    id: 'invite-friends',
    title: 'Invite Friends',
    description: 'Invite 3 friends to join NumbAI',
    reward: {
      type: 'STARS',
      amount: 10
    },
    icon: 'Users',
    completed: false
  },
  {
    id: 'share-app',
    title: 'Share NumbAI',
    description: 'Share NumbAI on your social media',
    reward: {
      type: 'NUMB',
      amount: 0.25
    },
    icon: 'Share2',
    completed: false
  },
  {
    id: 'community-chat',
    title: 'Join Community',
    description: 'Join our Telegram community chat',
    reward: {
      type: 'STARS',
      amount: 5
    },
    icon: 'MessageCircle',
    completed: false
  },
  {
    id: 'vote-projects',
    title: 'Vote Projects',
    description: 'Vote for 3 projects in the Gems section',
    reward: {
      type: 'NUMB',
      amount: 0.3
    },
    icon: 'ThumbsUp',
    completed: false
  }
];