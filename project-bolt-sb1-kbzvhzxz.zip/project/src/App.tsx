import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Navigation } from './components/Navigation';
import { Home } from './pages/Home';
import { Leaders } from './pages/Leaders';
import { Gems } from './pages/Gems';
import { Friends } from './pages/Friends';
import { Earn } from './pages/Earn';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-gray-900 via-black to-black">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/leaders" element={<Leaders />} />
          <Route path="/gems" element={<Gems />} />
          <Route path="/friends" element={<Friends />} />
          <Route path="/earn" element={<Earn />} />
        </Routes>
        <Navigation />
      </div>
    </Router>
  );
}

export default App;