export interface User {
  id: string;
  numbPoints: number;
  stars: number;
  referralCode: string;
  referredBy?: string;
  lastMiningTime?: number;
  completedTasks: string[];
  activeBoosts: {
    aiBoost?: {
      multiplier: number;
      expiresAt: number;
    };
  };
}

export interface Project {
  id: string;
  name: string;
  description: string;
  category: 'AI' | 'Web3';
  votes: number;
  imageUrl: string;
  projectUrl: string;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  reward: {
    type: 'NUMB' | 'STARS';
    amount: number;
  };
  completed: boolean;
  icon: 'Rocket' | 'Users' | 'Share2' | 'MessageCircle' | 'ThumbsUp';
}