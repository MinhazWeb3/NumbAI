import React from 'react';
import { TaskCard } from '../components/tasks/TaskCard';
import { dailyTasks } from '../data/tasks';
import { useStore } from '../store/useStore';
import { Card } from '../components/ui/card';

export const Earn = () => {
  const { user, completeTask, addNumbPoints } = useStore();

  const handleTaskComplete = (taskId: string) => {
    const task = dailyTasks.find(t => t.id === taskId);
    if (!task) return;

    completeTask(taskId);
    if (task.reward.type === 'NUMB') {
      addNumbPoints(task.reward.amount);
    }
  };

  const completedTasks = user?.completedTasks?.length || 0;
  const totalTasks = dailyTasks.length;
  const progress = (completedTasks / totalTasks) * 100;

  return (
    <div className="min-h-screen bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-gray-900 via-black to-black text-white pb-20">
      <div className="p-6">
        <h1 className="text-2xl font-bold mb-2">Daily Tasks</h1>
        <p className="text-gray-400 mb-6">Complete tasks to earn NUMB and Stars</p>

        <Card className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-400">Daily Progress</span>
            <span className="text-sm font-medium text-white">
              {completedTasks}/{totalTasks}
            </span>
          </div>
          <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-blue-500 to-purple-500 transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
        </Card>

        <div className="space-y-4 max-w-lg mx-auto">
          {dailyTasks.map((task) => (
            <TaskCard
              key={task.id}
              task={task}
              onComplete={handleTaskComplete}
            />
          ))}
        </div>
      </div>
    </div>
  );
};