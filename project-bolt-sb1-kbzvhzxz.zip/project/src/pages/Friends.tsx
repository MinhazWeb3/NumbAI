import React from 'react';

export const Friends = () => {
  return (
    <div className="min-h-screen bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-gray-900 via-black to-black text-white pb-20 p-4">
      <h1 className="text-2xl font-bold mb-4">Friends</h1>
      {/* Friends content will be implemented later */}
    </div>
  );
};