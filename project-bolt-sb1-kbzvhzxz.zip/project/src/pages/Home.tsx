import React from 'react';
import { Header } from '../components/Header';
import { MiningStation } from '../components/MiningStation';
import { AIBoost } from '../components/AIBoost';

export const Home = () => {
  return (
    <div className="min-h-screen bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-gray-900 via-black to-black text-white pb-20">
      <Header />
      
      <div className="p-4 space-y-6 max-w-lg mx-auto">
        <MiningStation />
        <AIBoost />
      </div>
    </div>
  );
};